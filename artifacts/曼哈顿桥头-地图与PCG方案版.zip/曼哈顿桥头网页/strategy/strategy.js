'use strict';
const P=window.PCG_PLAN;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $=s=>document.querySelector(s);
const list=a=>'<ul>'+a.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul>';
const td=a=>a.map(x=>'<td>'+esc(x)+'</td>').join('');
let selected='cq';
function renderDiagram(r){
 const lookup=Object.fromEntries(r.nodes.map(n=>[n[0],n]));
 const shared=$('#show-shared').checked?'<g opacity=".6"><path d="M130 35h500v300H130z" fill="#ecf0e7" stroke="#d8dfd2" stroke-dasharray="6 7"/><rect x="300" y="105" width="70" height="46" fill="#d9dfd2"/><rect x="425" y="246" width="83" height="41" fill="#d9dfd2"/><rect x="190" y="238" width="73" height="37" fill="#d9dfd2"/><rect x="480" y="105" width="67" height="39" fill="#d9dfd2"/></g>':'';
 const edges=r.edges.map(([a,b,k])=>{const u=lookup[a],v=lookup[b];return '<path class="diagram-edge '+esc(k||'walk')+'" d="M'+u[1]+' '+u[2]+' L'+v[1]+' '+v[2]+'"'+(k==='flow'?' marker-end="url(#arrow)"':'')+'/>'}).join('');
 const nodes=r.nodes.map(n=>'<g><circle class="diagram-node '+esc(n[4])+'" cx="'+n[1]+'" cy="'+n[2]+'" r="'+(n[3].length>3?38:32)+'"/><text class="diagram-text diagram-node-label '+esc(n[4])+'" x="'+n[1]+'" y="'+n[2]+'">'+esc(n[3])+'</text></g>').join('');
 $('#topology').innerHTML='<svg viewBox="0 0 770 420" role="img" aria-label="'+esc(r.title)+'的目标与路线示意"><title>'+esc(r.title)+'</title><defs><marker id="arrow" viewBox="0 0 10 10" refX="18" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#244b3a"/></marker></defs>'+shared+edges+nodes+'<text class="diagram-text diagram-legend" x="24" y="405">'+esc(r.id==='cq'?'粗线：载具干线 ｜ 细线：步兵连接':r.id==='bt'?'虚线箭头：阶段关系 ｜ 实线：阶段内/攻守连接':r.id==='tdm'?'S1–S8：示意候选出生组 ｜ 橙色：主要交战区':'绿色：入场/出生 ｜ 橙色：主要目标 ｜ 虚边：撤离')+'</text></svg>';
}
function choose(id){selected=id;const r=P.recipes.find(x=>x.id===id);document.querySelectorAll('[data-recipe]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.recipe===id)));$('#diagram-label').textContent=r.family+' / '+r.variant;$('#recipe-detail').innerHTML='<span class="pill">'+esc(r.family)+'</span><h3>'+esc(r.title)+'</h3><div class="recipe-facts"><span>'+esc(r.players)+'</span><span>'+esc(r.size)+'</span></div><p>'+esc(r.intent)+'</p><h4>生成骨架</h4><p>'+esc(r.geometry)+'</p><h4>这一配方的硬约束</h4>'+list(r.hardRules);$('#recipe-bottom').innerHTML='<div><h4>局内允许变化</h4><p>'+esc(r.random)+'</p></div><div><h4>发布后锁定</h4><p>'+esc(r.lock)+'</p></div><div><h4>重点测什么</h4>'+list(r.metrics)+'</div>';renderDiagram(r);}
$('#mode-tabs').innerHTML=P.recipes.map(r=>'<button class="mode-tab" data-recipe="'+r.id+'" aria-pressed="false">'+esc(r.label)+'</button>').join('');
$('#mode-tabs').addEventListener('click',e=>{const b=e.target.closest('[data-recipe]');if(b)choose(b.dataset.recipe)});$('#show-shared').addEventListener('change',()=>renderDiagram(P.recipes.find(x=>x.id===selected)));
$('#layers').innerHTML=P.layers.map((x,i)=>'<article class="layer"><small>L'+i+'</small><h3>'+esc(x[0])+'</h3><b>'+esc(x[1])+'</b><p>'+esc(x[2])+'</p></article>').join('');
$('#variants').innerHTML=P.recipes.map(r=>'<tr>'+td([r.variant+' / '+r.label,r.size,r.retain,r.geometry])+'</tr>').join('');
$('#pipeline-list').innerHTML=P.pipeline.map(x=>'<li><div><h3>'+esc(x[0])+'</h3><p>'+esc(x[1])+'</p></div><div class="pipeline-out">'+esc(x[2])+'</div></li>').join('');
$('#contracts-grid').innerHTML=P.contracts.map(x=>'<article class="contract"><small>'+esc(x[0])+'</small><h3>'+esc(x[1])+'</h3><p>'+esc(x[2])+'</p></article>').join('');
$('#destruction').innerHTML=P.recipes.map(r=>'<tr>'+td([r.label,r.destruction,r.reset])+'</tr>').join('');
$('#audit').innerHTML=P.audit.map(x=>'<article class="audit-card"><span class="pill">'+esc(x.status)+'</span><h3>'+esc(x.title)+'</h3>'+list(x.items)+x.evidence.map(p=>'<code>'+esc(p)+'</code>').join('')+'</article>').join('');
$('#modules').innerHTML=P.modules.map(x=>'<tr>'+td([x[0],x[1]+'：'+x[2],x[3]])+'</tr>').join('');
$('#milestones').innerHTML=P.milestones.map(x=>'<article class="milestone"><strong>'+x.code+'</strong><div><h3>'+esc(x.title)+'</h3><p>'+esc(x.deliver)+'</p></div><div class="gate"><b>通过后再进入下一步</b><p>'+esc(x.gate)+'</p><p>'+esc(x.parallel)+'</p></div></article>').join('');
$('#gates').innerHTML=P.gates.map(x=>'<tr>'+td(x)+'</tr>').join('');
$('#sources-list').innerHTML=P.sources.map(x=>'<article class="source-note"><a href="'+esc(x[1])+'" target="_blank" rel="noopener">'+esc(x[0])+' ↗</a><p>'+esc(x[2])+'</p></article>').join('');
function memory(){const s=Number($('#voxel-size').value),n=Math.round(600/s)*Math.round(450/s)*Math.round(50/s);$('#memory-count').textContent=(n/1e8).toLocaleString('zh-CN',{maximumFractionDigits:3})+' 亿格';$('#memory-bytes').textContent='仅格数据约 '+(n/1e9).toLocaleString('zh-CN',{maximumFractionDigits:3})+' GB';}
$('#voxel-size').addEventListener('change',memory);memory();choose('cq');
