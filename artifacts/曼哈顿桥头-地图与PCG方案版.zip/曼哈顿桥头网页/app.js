
const refs = window.ATLAS_REFERENCES;
const assetBase = document.body.dataset.page==='art'?'../':'./';
const refMap=Object.fromEntries(refs.map(r=>[r.id,r]));
const items=window.ATLAS_ITEMS||[];
const inventory=window.ATLAS_INVENTORY||[];
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sourceUrl=r=>r.sourceLocal?assetBase+r.source:r.source;
const licenseLink=r=>r.licenseUrl?'<a href="'+escape(r.licenseUrl)+'" target="_blank" rel="noopener">'+escape(r.license)+'</a>':escape(r.license);
const credit=r=>'<p class="credit">'+escape(r.author)+' · '+licenseLink(r)+'<br><a href="'+escape(sourceUrl(r))+'" target="_blank" rel="noopener">'+(r.sourceLocal?'打开旧版参考原图':'查看参考图来源')+' ↗</a></p>';
const photo=(r,index,contain=false)=>'<button class="zoom ref-photo '+(contain?'contain':'')+(r.category==='武器'?' real-gun-photo':'')+'" data-ref="'+r.id+'" aria-label="放大：'+escape(r.title)+'"><img src="'+assetBase+r.file+'" alt="'+escape(r.title)+'" loading="lazy"><span class="photo-index">'+(r.category==='武器'?'实枪照片':'REF')+' '+String(index+1).padStart(2,'0')+'</span><span class="zoom-icon" aria-hidden="true">↗</span></button>';
for(const grid of document.querySelectorAll('[data-gallery]')){grid.innerHTML=grid.dataset.gallery.split(',').map((id,i)=>{const r=refMap[id];return '<figure class="ref-card">'+photo(r,i)+'<figcaption class="ref-content"><span class="pill">'+(r.kind||(r.category==='风格'?'官方游戏截图':'现实照片参考'))+'</span><h3>'+escape(r.title)+'</h3><p>'+escape(r.caption)+'</p>'+credit(r)+'</figcaption></figure>'}).join('')}
if(document.body.dataset.page==='art'){
 let filter='武器';
 const input=document.getElementById('asset-search');
 const syncButtons=()=>document.querySelectorAll('[data-filter]').forEach(b=>{const on=b.dataset.filter===filter;b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on))});
 const render=()=>{const q=input.value.trim().toLowerCase();const result=items.filter(x=>(filter==='全部'||x.cat===filter)&&JSON.stringify(x).toLowerCase().includes(q));
 document.getElementById('result-count').textContent='显示 '+result.length+' / '+items.length+' 项参考与需求';
 document.getElementById('asset-grid').innerHTML=result.length?result.map((x,i)=>{const r=refMap[x.ref];return '<article class="asset-card" data-asset-id="'+escape(x.id||x.ref)+'">'+photo(r,i,['武器','装备','物品'].includes(x.cat))+'<div class="asset-body"><div class="asset-meta"><span class="pill">'+x.cat+'</span><span>'+escape(x.count)+'</span></div><h3>'+escape(x.title)+'</h3><p>'+escape(x.spec)+'</p><div class="tokens">'+x.names.map(n=>'<span>'+escape(n)+'</span>').join('')+'</div><details><summary>查看制作交付要求</summary><p style="margin-top:10px">'+escape(x.delivery)+'</p><p class="reference-note">'+escape(r.caption)+'</p></details>'+credit(r)+'</div></article>'}).join(''):'<div class="empty"><h3>没有找到匹配的资源</h3><p>试试“伸缩梯”“AK-74”，或点击“重置筛选”。</p></div>';
 };
 document.querySelectorAll('[data-filter]').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.filter;syncButtons();render()}));
 input.addEventListener('input',render);
 document.getElementById('clear-search').addEventListener('click',()=>{input.value='';filter='全部';syncButtons();render()});
 syncButtons();render();
 document.getElementById('inventory-grid').innerHTML=inventory.map(group=>'<article class="inventory-group"><div class="inventory-heading"><h3>'+escape(group.category)+' <span class="pill">'+group.entries.length+' 项</span></h3><p class="note">'+escape(group.note)+'</p></div><div class="mini-item-grid">'+group.entries.map((x,i)=>{const r=refMap[x.ref];return '<figure class="mini-item" data-item-id="'+x.id+'">'+photo(r,i,true)+'<figcaption><h4>'+escape(x.title)+'</h4><p>'+escape(x.spec)+'</p><details><summary>图片说明与来源</summary><p>'+escape(r.caption)+'</p>'+credit(r)+'</details></figcaption></figure>'}).join('')+'</div></article>').join('');
 const budgets=[['建筑模块',80],['道路 / 水岸 / 地形',28],['环境陈设',88],['可搜索容器',16],['模式设施',16],['桥梁地标',12]];
 document.getElementById('budget-bars').innerHTML=budgets.map(([label,n])=>'<div class="bar-row"><span>'+label+'</span><span class="bar"><i style="width:'+n/88*100+'%"></i></span><strong>'+n+'</strong></div>').join('');
 document.getElementById('vfx-list').innerHTML=['枪口焰','抛壳','弹迹 / 示踪','8 材质命中','穿孔 / 剥落','爆炸','结构断裂 / 坍塌','烟雾遮挡','闪光 / 震撼反馈','局部燃烧','载具损坏 / 殉爆','撤离 / 合同 / 支援提示'].map((x,i)=>'<span>'+String(i+1).padStart(2,'0')+' / '+x+'</span>').join('');
}
const dialog=document.getElementById('lightbox');
document.addEventListener('click',e=>{const b=e.target.closest('[data-ref],[data-image]');if(!b)return;const r=b.dataset.ref?refMap[b.dataset.ref]:{file:b.dataset.image,title:b.dataset.title,source:b.dataset.source,caption:'证据参考图片 · 原图比例展示'};
 document.getElementById('lightbox-title').textContent=r.title;
 const img=document.getElementById('lightbox-image');img.src=assetBase+r.file;img.alt=r.title;
 document.getElementById('lightbox-foot').innerHTML='<p>'+escape(r.caption||'')+'</p>'+(r.author?credit(r):'<a href="'+escape(r.source)+'" target="_blank" rel="noopener">查看原始来源 ↗</a>');
 dialog.showModal();
});
dialog.querySelector('.close-dialog').addEventListener('click',()=>dialog.close());
dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientY<r.top||e.clientY>r.bottom||e.clientX<r.left||e.clientX>r.right)dialog.close()}});
